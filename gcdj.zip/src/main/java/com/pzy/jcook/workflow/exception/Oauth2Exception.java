package com.pzy.jcook.workflow.exception;

public class Oauth2Exception extends RuntimeException{
	private static final long serialVersionUID = -3472408913310895419L;

}

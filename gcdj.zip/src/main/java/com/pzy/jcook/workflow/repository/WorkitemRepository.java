package com.pzy.jcook.workflow.repository;

import com.pzy.jcook.sys.repository.BaseRepository;
import com.pzy.jcook.workflow.entity.Workitem;

public interface WorkitemRepository   extends BaseRepository<Workitem ,Long>{
}

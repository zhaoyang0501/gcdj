package com.pzy.jcook.workflow.repository;

import com.pzy.jcook.sys.repository.BaseRepository;
import com.pzy.jcook.workflow.entity.Ship;

public interface ShipRepository   extends BaseRepository<Ship ,Long>{
}

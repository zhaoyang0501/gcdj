package com.pzy.jcook.workflow.exception;

public class NotBindUserException extends RuntimeException{
	private static final long serialVersionUID = 1554870840918530037L;
}

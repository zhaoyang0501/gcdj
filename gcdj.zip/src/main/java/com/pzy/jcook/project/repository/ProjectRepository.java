package com.pzy.jcook.project.repository;

import com.pzy.jcook.project.entity.Project;
import com.pzy.jcook.sys.repository.BaseRepository;

public interface ProjectRepository   extends BaseRepository<Project ,Long>{
}

package com.pzy.jcook.project.service;
import org.springframework.stereotype.Service;

import com.pzy.jcook.project.entity.Project;
import com.pzy.jcook.sys.service.BaseService;
@Service
public class ProjectService extends BaseService<Project, Long> {
}

package com.pzy.jcook.sys.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;

import com.pzy.jcook.sys.entity.Item;
import com.pzy.jcook.sys.entity.User;

public interface ItemRepository   extends BaseRepository<Item ,Long>{
	
}

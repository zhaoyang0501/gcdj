package com.pzy.jcook.sys.repository;

import com.pzy.jcook.sys.entity.Role;
public interface RoleRepository   extends BaseRepository<Role ,Long>{
}
